# Day 1 – Environment Setup

## Internship Task

The objective of Day 1 was to set up the complete Data Science development environment and verify that everything works correctly.

## Tasks Completed

- Learned the basics of Data Science.
- Installed Python.
- Installed Visual Studio Code.
- Installed Jupyter Notebook.
- Installed Git.
- Created a GitHub Repository.
- Executed the first Python program.

## Tools Installed

- Python 3.x
- Visual Studio Code
- Jupyter Notebook
- Git
- GitHub

## First Python Program

```python
print("Hello, Data Science!")
```

Output:
```
Hello, Data Science!
```

## Screenshots
Add screenshots for:
- Python Installation
- VS Code
- Jupyter Notebook
- Git Installation
- GitHub Repository
- Python Output

Author: Ketha Lohitha
