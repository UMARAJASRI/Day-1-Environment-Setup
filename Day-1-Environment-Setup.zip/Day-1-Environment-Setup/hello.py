print("Hello, Data Science!")
print("My name is Ketha Lohitha.")
print("Day 1 Internship Task Completed Successfully.")
